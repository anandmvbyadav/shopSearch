package com.hcl.exception;

public class DataInputException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public DataInputException(String message) {
		super(message);
	}
}
